import { DEFAULT_VERSION_CREATE_FORM_PROPS } from './default-version-create-form-props';

export const DEFAULT_VERSION_EDIT_FORM_PROPS = DEFAULT_VERSION_CREATE_FORM_PROPS;
