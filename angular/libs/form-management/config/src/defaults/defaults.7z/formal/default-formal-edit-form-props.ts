import { DEFAULT_FORMAL_CREATE_FORM_PROPS } from './default-formal-create-form-props';

export const DEFAULT_FORMAL_EDIT_FORM_PROPS = DEFAULT_FORMAL_CREATE_FORM_PROPS;
