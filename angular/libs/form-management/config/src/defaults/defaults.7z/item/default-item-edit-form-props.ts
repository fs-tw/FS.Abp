import { DEFAULT_ITEM_CREATE_FORM_PROPS } from './default-item-create-form-props';

export const DEFAULT_ITEM_EDIT_FORM_PROPS = DEFAULT_ITEM_CREATE_FORM_PROPS;
