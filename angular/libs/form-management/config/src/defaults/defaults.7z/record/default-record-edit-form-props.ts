import { DEFAULT_RECORD_CREATE_FORM_PROPS } from './default-record-create-form-props';

export const DEFAULT_RECORD_EDIT_FORM_PROPS = DEFAULT_RECORD_CREATE_FORM_PROPS;
