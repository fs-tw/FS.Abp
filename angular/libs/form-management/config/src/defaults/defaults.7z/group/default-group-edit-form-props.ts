import { DEFAULT_GROUP_CREATE_FORM_PROPS } from './default-group-create-form-props';

export const DEFAULT_GROUP_EDIT_FORM_PROPS = DEFAULT_GROUP_CREATE_FORM_PROPS;
