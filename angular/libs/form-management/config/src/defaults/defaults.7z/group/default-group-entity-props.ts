import { EntityProp, ePropType } from '@abp/ng.theme.shared/extensions';
import {Fs} from '@fs-tw/form-management/proxy';
import { of } from 'rxjs';

export const DEFAULT_GROUP_ENTITY_PROPS = EntityProp.createMany<Fs.FormManagement.Forms.Dtos.GroupDto>([
   
    {
        type: ePropType.String,
        name: 'code',
        displayName: 'FormManagement::FS.Group.Code',
        sortable: true,
        columnWidth: 100,
      },
      {
        type: ePropType.String,
        name: 'parentid',
        displayName: 'FormManagement::FS.Group.ParentId',
        sortable: true,
        columnWidth: 100,
      },
      {
        type: ePropType.String,
        name: 'level',
        displayName:'FormManagement::FS.Group.Level',
        sortable: true,
        columnWidth: 100,
      },
      {
        type: ePropType.String,
        name: 'displayname',
        displayName:'FormManagement::FS.Group.DisplayName',
        sortable: true,
        columnWidth: 100,
      },
      {
        type: ePropType.String,
        name: 'formalid',
        displayName:'FormManagement::FS.Group.FormalId',
        sortable: true,
        columnWidth: 100,
      },
  
]);
