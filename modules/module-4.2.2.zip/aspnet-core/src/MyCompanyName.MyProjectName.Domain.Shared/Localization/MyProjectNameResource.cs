﻿using Volo.Abp.Localization;

namespace MyCompanyName.MyProjectName.Localization
{
    [LocalizationResourceName("MyProjectName")]
    public class MyProjectNameResource
    {
        
    }
}
