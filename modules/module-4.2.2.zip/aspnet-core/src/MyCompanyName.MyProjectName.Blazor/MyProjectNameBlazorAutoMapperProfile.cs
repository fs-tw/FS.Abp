﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.Blazor
{
    public class MyProjectNameBlazorAutoMapperProfile : Profile
    {
        public MyProjectNameBlazorAutoMapperProfile()
        {
            /* You can configure your AutoMapper mapping configuration here.
             * Alternatively, you can split your mapping configurations
             * into multiple profile classes for a better organization. */
        }
    }
}