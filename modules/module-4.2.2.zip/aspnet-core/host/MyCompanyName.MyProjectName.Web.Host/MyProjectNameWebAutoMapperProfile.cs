﻿using AutoMapper;

namespace MyCompanyName.MyProjectName
{
    public class MyProjectNameWebAutoMapperProfile : Profile
    {
        public MyProjectNameWebAutoMapperProfile()
        {
            //Define your AutoMapper configuration here for the Web project.
        }
    }
}
