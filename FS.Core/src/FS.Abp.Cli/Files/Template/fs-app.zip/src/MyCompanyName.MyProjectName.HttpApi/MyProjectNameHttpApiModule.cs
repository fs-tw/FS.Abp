﻿using Volo.Abp.Modularity;

namespace MyCompanyName.MyProjectName
{
    [DependsOn(
        typeof(MyProjectNameApplicationContractsModule),
        typeof(FS.Common.CommonHttpApiModule)
        )]
    public class MyProjectNameHttpApiModule : AbpModule
    {
        
    }
}
