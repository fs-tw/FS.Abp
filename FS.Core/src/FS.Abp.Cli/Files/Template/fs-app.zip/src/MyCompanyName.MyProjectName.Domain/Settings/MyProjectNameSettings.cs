﻿namespace MyCompanyName.MyProjectName.Settings
{
    public static class MyProjectNameSettings
    {
        private const string Prefix = "MyProjectName";

        //Add your own setting names here. Example:
        //public const string MySetting1 = Prefix + ".MySetting1";
    }
}