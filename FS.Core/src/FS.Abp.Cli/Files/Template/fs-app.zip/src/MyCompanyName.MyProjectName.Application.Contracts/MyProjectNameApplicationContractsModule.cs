﻿using Volo.Abp.Modularity;

namespace MyCompanyName.MyProjectName
{
    [DependsOn(
        typeof(MyProjectNameDomainSharedModule),
        typeof(FS.Common.CommonApplicationContractsModule)
    )]
    public class MyProjectNameApplicationContractsModule : AbpModule
    {

    }
}
