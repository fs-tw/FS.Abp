﻿module.exports = {
    aliases: {
        
    },
    mappings: {
        
    }
};
