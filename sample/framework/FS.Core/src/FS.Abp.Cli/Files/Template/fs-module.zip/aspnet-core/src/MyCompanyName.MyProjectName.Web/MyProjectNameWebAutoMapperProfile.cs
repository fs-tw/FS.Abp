﻿using AutoMapper;

namespace MyCompanyName.MyProjectName.Web
{
    public class MyProjectNameWebAutoMapperProfile : Profile
    {
        public MyProjectNameWebAutoMapperProfile()
        {
            /* You can configure your AutoMapper mapping configuration here.
             * Alternatively, you can split your mapping configurations
             * into multiple profile classes for a better organization. */
        }
    }
}